from flask import Flask, render_template, request
import dao

app = Flask(__name__)

@app.route("/")
def index():
    catagories = dao.load_catagories()
    q = request.args.get("q")
    products = dao.load_products(q)


    print(q)
    return render_template("index.html", catagories = catagories, products=products)

if __name__ == '__main__':
    app.run(debug=True)